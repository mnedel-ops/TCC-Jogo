extends CharacterBody3D
class_name NPC

@onready var dialoguearea : Area3D = $DialogueCollision
@onready var is_zone : bool = false 
@onready var dialogueBox : Label = $Root/Dialogo

@export var figther : bool = false
@onready var combat_collision: Area3D = $CombatCollision
@onready var is_combat_zone : bool = false 

@export var alchemon1:int =1
@export var alchemon2: int =1
var alchemon_level: int = -1


func _ready() -> void:
	dialoguearea.area_entered.connect(_on_area_entered)
	dialoguearea.area_exited.connect(_on_area_exited)
	dialogueBox.visible = false
	
	if figther:
		combat_collision.area_entered.connect(_on_combat_area_entered)
		combat_collision.area_exited.connect(_on_combat_area_exited)


func _process(delta: float) -> void:
	if Input.is_action_just_pressed("ui_interact") and is_zone and is_combat_zone != true:
		talk()

#Func do dialogo
func _on_area_entered(area: Area3D) -> void:
	if area.is_in_group("player"):
		is_zone = true
func _on_area_exited(area: Area3D) -> void:
	if is_zone:
		is_zone = false
		dialogueBox.visible =false

func talk():
	print("Estamos conversando...")
	dialogueBox.visible = true
	

#Func do combate
func _on_combat_area_entered(area: Area3D) -> void:
	if CombatSignal.in_combat:
		return # characters being moved around by the battle, ignore
	if area.is_in_group("player") and is_combat_zone !=true:
		is_combat_zone = true
		print("Vou te quebrar na porrada")
		print_debug(alchemon1, alchemon2)

		CombatSignal.enemy_node = self
		CombatSignal.enemy_level = alchemon_level
		CombatSignal.is_trainer_battle = true
		CombatSignal.combat_start.emit(alchemon1, alchemon2)
		
func _on_combat_area_exited(area: Area3D) -> void: #nao acho que precise deste
	if area.is_in_group("player"):
		is_combat_zone = false
		print("Cansei de te espancar. Vaza")
